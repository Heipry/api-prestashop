<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>formShipping</title>
</head>
<body>
	
<h2>Introduce id de orden</h2>
	<form action="get-shipping.php" method="get">
		<input type="text" name="id">
		<input type="submit" value="Enviar">
	</form> 
</body>
</html>